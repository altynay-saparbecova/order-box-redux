import "./App.css";
import { OrderBasket } from "./components/OrdersBasket";

function App() {
  return (
    <div className="App">
      <OrderBasket />
    </div>
  );
}

export default App;

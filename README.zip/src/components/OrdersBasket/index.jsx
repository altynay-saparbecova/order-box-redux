import React, { useEffect } from 'react'
import { data } from '../../store/data'
import "antd/dist/antd.css";
import { useSelector, useDispatch } from 'react-redux'
import { add_order, add_delete } from '../../store/actions'
import DeleteIcon from '@material-ui/icons/Delete';



export const OrderBasket = () => {
    //orders деген озгормо ачабыз
    //state ке кайрылып щквукы деген ключту кайтарып ,озгормого туруп калат
    const orders = useSelector(state => state.orders)
    const dispatch = useDispatch()
    // localStorage хранилища
    useEffect(() => {
        localStorage.setItem('orders', JSON.stringify(orders))
    }, [orders])
    // // alert
    const [open, setOpen] = React.useState(false);


    const handleClick = () => {
        setOpen(true);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    return <div style={styles.orderContainer}>
        <div style={styles.menuContainer}>
            <h1>Menu</h1>
            {/*data  ны рендер кылабыз */}
            <ul>
                {
                    data.map((el, id) => {
                        //бул жакта  onClick события кошуп диспатч менен сторго объект жонотобуз
                        //add_order деген функцияны чакырабыз ал item кутот -объект келет
                        return <li
                            //добавить заказы
                            onClick={() => {
                                dispatch(add_order(el))
                                //aler 
                                handleClick()
                            }}
                            style={{ cursor: 'pointer', listStyle: 'none' }}
                            key={id} >
                            {el.title} <b>{el.price}</b>
                            {/* <img src={data.img} /> */}
                        </li>

                    })
                }
            </ul>
        </div>
        <div style={styles.basketContainer}>
            <h1>Orders</h1>
            <ul >
                {

                    orders.map((el, id) => {
                        return <li style={{ cursor: 'pointer', listStyle: 'none' }} key={id}>

                            <span>{el.title} </span>
                            <b>: {el.price} * {el.count} = {el.sum}</b>
                            <span onClick={() => dispatch(add_delete(el))}>{/*удалить заказ */}
                                <DeleteIcon />
                            </span>
                        </li>
                    })

                }
            </ul>
        </div>
    </div >
}

const styles = {
    orderContainer: {
        display: 'flex',
        justifyContent: 'space-between',
    },
    menuContainer: {
        width: '50%',

    },
    basketContainer: {
        width: '50%',
        justifyContent: 'space-between',

    }
}
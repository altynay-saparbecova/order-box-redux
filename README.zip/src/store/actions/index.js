export const ADD_ORDER = "ADD_ORDER";
export const ADD_DELETE = "ADD_DELETE"
// export const add_order = () => {
//   return {
// type: ADD_ORDER,
//   };
// };

export const add_order = (item) => ({
  type: ADD_ORDER,
  payload: item
});

export const add_delete = (item) => ({
  type: ADD_DELETE,
  payload: item
});
// import { img } from './images/coffe.png'
export const data = [
  {
    title: "burger",
    // img: img,
    price: 100
  },
  { title: "cola", price: 80 },
  { title: "fries", price: 150 },
  { title: "tea", price: 50 },
];
